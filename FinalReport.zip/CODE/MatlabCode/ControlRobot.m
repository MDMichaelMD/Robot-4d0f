clear, close all
addpath("robotics toolbox\")


%% settings

sendToArduino = 0; % if enables sends the joint values to the arduino
calibrateRobot = 0; % calibrates the robot before starting the movement
simulateRobot = 1; % if enabled simulates the movement of the robot
trajPlanMethod = 1; % 0 - TaskSpace Interpolation & inverse kin; 1 - Resolved rate algorithm
trajShape = 'triangle'; % shape the robot should follow ['circle', 'square', 'triangle']
    
% start motor position
q0 = [0 0 0 0]';
q0 = [-10 -75 -90 -20]';

%% parameters

% robot (arm lengths)
% [ground plane box - rotation axis motor 2; RotAx Motor 2 - RotAx Motor 3; RotAx Motor 3 - RotAx Motor 4; RotAx Motor 4 - Pen Tip]
ArmLengths = [193.3; 193.2; 150.5; 59.7]*1e-3;   % [m]

% time
t_traj = 16;    % time the robot has to complete the given trajectory
dt = 0.25;       % duration of one timestep
t_move = 5;     % movement time for the robot to reach a certain point
t_pause = 10;    % pause time

% animation
dt_vid = 1;

% RR-Algorithm settings
RRsettings.iter = 1000; % max amount of iterations
RRsettings.dt = 0.05; % timestep of the RR-algorithm [s]
RRsettings.p_error_Tol = 0.001; % [m] the acceptable tolerance is 1mm
RRsettings.v = 0.01;   % [m/s] the speed the robot travels at

% shape
nTurns_circle = 1; % do multiple turns
nPoints_circle = 40; % number of points on the circle (only RR-alg)
circlePos = [.25;0;0.137]; % [xPos,yPos,zPos] [m] : position of the circle center
% circlePos = [0;0;0.55]; % [xPos,yPos,zPos] [m] : position of the circle center
circleRot = [0,68,0];    % [xRot,yRot,zRot] [°DEG] : Roll-Pitch-Yaw Angles in global frame
circleR = 0.05;          % radius of the circle [m]
circleToolOri = 70;     % negative rotation around x1-axis of the EE
nAddPoints_square = 1; % adds n extra points bettwen the corner points
%squarePos = [.25;0;0.35]; % [xPos,yPos,zPos] [m] : position of the square center
squarePos = [0.28;0;0.1];
squareRot = [180,-70,0];   % [xRot,yRot,zRot] [°DEG] : Roll-Pitch-Yaw Angles in global frame
squareA = 0.1;          % side length of the square [m]
squareToolOri = 60;      % negative rotation around x1-axis of the EE
nAddPoints_triangle = 3; % adds n extra points bettwen the corner points
trianglePos = [.25;0;0.040];   % [xPos,yPos,zPos] [m] : position of the triangle center
triangleRot = [0,88,0];      % [xRot,yRot,zRot] [°DEG] : Roll-Pitch-Yaw Angles in global frame
triangleA = 0.1;            % base length of the triangle [m]
triangleH = 0.1;            % height of the triangle [m]
triangleToolOri = 90;        % negative rotation around x1-axis of the EE


%% Motor position calculation

% Initialize the serial communication with the Arduino
if sendToArduino
    arduino = serialport('COM3', 9600); % connects to the serial port with a baudrate of 9600
    pause(1); % otherwise the first msg gets ignored

    % if enabled start the calibration
    if calibrateRobot
        writeline(arduino, '<c>');
    end
end

% choose the type which method to use to plan the trajectory movement
if trajPlanMethod
    % Resolved Rate Algorithm
    
    % shape
    switch trajShape
        case 'default'
            % default is the square for now

            % get the goal trajectory
            points = squareBuilder(squarePos,squareA,squareRot);
        case 'circle'
            % get the goal trajectory
            points = circleBuilder(circlePos,circleR,circleRot,nTurns_circle,nPoints_circle);
        case 'square'
            % get the goal trajectory
            points = squareBuilder(squarePos,squareA,squareRot,nAddPoints_square);
        case 'triangle'
            % get the goal trajectory
            points = triangleBuilder(trianglePos,triangleA,triangleH,triangleRot,nAddPoints_triangle);
    end

    % Initialize variable to store all joint values
    q_t_full = [];
    p_t_full = [];

    % run to the first position
    RRsettings.iter = 10000;
    [q_t,p_t]  = resolvedRateAlgorithm(q0,points(:,1),ArmLengths,RRsettings);
    q_t_full = [q_t_full,q_t];
    p_t_full = [p_t_full,p_t];
    trajStart_indx = size(p_t_full,2);

    % run the RR-Algorithm to get the motor angles
    RRsettings.iter = 1000;
    [q_t,p_t]  = resolvedRateAlgorithm(q_t_full(:,end),points,ArmLengths,RRsettings);
    q_t_full = [q_t_full,q_t];
    p_t_full = [p_t_full,p_t];

    % first we have to do some data processing
    % we don't want to show the robot for every timestep of the algorithm since those are way too many
    step_size = round(dt_vid/RRsettings.dt);
    q_t = q_t_full(:,1:step_size:end); % extract one data point every [step_size] steps
    p_t = p_t_full(:,1:step_size:end);

    % time vector
    t = 0:RRsettings.dt:((size(q_t,2)-1)*RRsettings.dt);
else
    % Task Space Interpolation & Inverse Kinematics

    % shape
    switch trajShape
        case 'default'
            % default is the square for now
            [t,p_t,pd_t,pdd_t] = InterpolTrajec_square(squarePos,squareA,squareRot,t_traj,dt);
            q_t = invKin(ArmLengths,p_t,squareToolOri);
        case 'circle'
            [t,p_t,pd_t,pdd_t] = InterpolTrajec_circle(circlePos,circleR,circleRot,t_traj,dt);
            q_t = invKin(ArmLengths,p_t,circleToolOri);
        case 'square'
            [t,p_t,pd_t,pdd_t] = InterpolTrajec_square(squarePos,squareA,squareRot,t_traj,dt);
            q_t = invKin(ArmLengths,p_t,squareToolOri);
        case 'triangle'
            [t,p_t,pd_t,pdd_t] = InterpolTrajec_triangle(trianglePos,triangleA,triangleH,triangleRot,t_traj,dt);
            q_t = invKin(ArmLengths,p_t,triangleToolOri);
    end

end




%% Robot movement

% send motor pos to arduino
if sendToArduino
    if calibrateRobot
        pause(60); % just wait since this takes ages
    end
    if trajPlanMethod
        % move to start position of the shape
        trajStart_indx = round(trajStart_indx/step_size);
        msg1 = sendMsgArduino(arduino,q_t(:,1:trajStart_indx),dt);
        fprintf('Sent msg with %d characters to the arduino: \n', length(msg1));
        disp(msg1);
        pause(2.5*t_pause); % pause
        

        % follow the trajectory
        msg2 = sendMsgArduino(arduino,q_t(:,trajStart_indx:end),dt);
        fprintf('Sent msg with %d characters to the arduino: \n', length(msg2));
        disp(msg2);
        pause(t_pause); % pause
    else
        % move to a point above the start pos
        % q_t_single = invKin_singlePoint(ArmLengths,p_t(:,1)+[0 0 0.01]',90);
        % sendMsgArduino(arduino,q_t_single',t_move);
        % pause(t_pause); % pause
        
        % move to start position of the shape
        msg1 = sendMsgArduino(arduino,q_t(:,1)+[0 5 0 0]',t_move);
        fprintf('Sent msg with %d characters to the arduino: \n', length(msg1));
        disp(msg1);
        pause(t_pause); % pause
        
        % follow the trajectory
        msg2 = sendMsgArduino(arduino,q_t,dt);
        fprintf('Sent msg with %d characters to the arduino', length(msg2));
        disp(msg2);
        pause(t_pause); % pause
    end
    
end

% simulate the robot movement
if simulateRobot
    if trajPlanMethod
    % Resolved Rate Algorithm
        moveRobot(ArmLengths,q_t,dt,points);
    else
    % Task Space Interpolation & Inverse Kinematics
        moveRobot(ArmLengths,q_t,dt,p_t);
    end
end
