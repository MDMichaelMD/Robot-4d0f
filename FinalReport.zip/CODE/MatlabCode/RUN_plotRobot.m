clear, close all
addpath("robotics toolbox\")

% Arm length
% [ground plane box - rotation axis motor 2; RotAx Motor 2 - RotAx Motor 3; RotAx Motor 3 - RotAx Motor 4; RotAx Motor 4 - Pen Tip]
ArmLengths = [193.3; 193.2; 150.5; 59.7]*1e-3;   % [m]

% Motor positions
% MotorPos = [theta1, theta2, theta3, theta4] < all four motor positions !! [DEG] !!
% MotorPos = [45, -90, -45, 45];  % !! [DEG] !!
tPos = [0 0.3 0.2];
tOri = 0;
MotorPos = invKin_singlePoint(ArmLengths, tPos, tOri)

% Settings for the robot plot
PlotSettings.EnabledFrames = [1,1,1,1,1];   % [Frame0, Frame1, Frame2, Frame3, Frame4] enable/disable plottings these frames

% plot the robot in the current position
plotRobot(ArmLengths,MotorPos,PlotSettings)