function [t,q_t,qd_t,qdd_t] = InterpolTrajec_circle(center,radius,rot,t_length,t_stepSize)
%CIRCLETRAJECBUILD builder for a square trajectory
%   builds a circle based from its center point
%
%   input:
%       center - [x,y,z] : center point of the circle
%       r - [m] : radius
%       rot - [zRot,yRot,xRot] [°DEG] : Roll-Pitch-Yaw Angles in global frame
%       t_length - [s] : timelength for the whole trajectory
%       t_stepSize - [s] : duration of one timestep

%   CIRCLE [0,0,0] orientation
%
%        z↑     
%        ◯ 1 → y
%              

% Get all points on the circle
    
    % time vector
    t = 0:t_stepSize:t_length;

    % we want a smooth movement along the whole circumference
    zero_vec = zeros(3,1);
    [alpha,omega,~] =  interpolTaskSpace([[0,0,0]',zero_vec,zero_vec], [[0,0,(2+1)*pi]',zero_vec,zero_vec], t);
    % we do a interpolation from 0 - 2pi [RAD] in t
    alpha = alpha(3,:); % only care about this dimension
    omega = omega(3,:);
    
    % Calculate y and z coordinates based on the parametric equations
    y = radius*cos(alpha);
    z = radius*sin(alpha);
    points_c = [zeros(1,length(y));y;z];
    % velocity
    x_dt = -radius.*omega.*sin(alpha);
    y_dt = radius.*omega.*cos(alpha);
    vel_c = [x_dt; y_dt; zeros(1,length(x_dt))];
    % acceleration
    x_ddt = -radius.*omega.^2.*cos(alpha);
    y_ddt = -radius.*omega.^2.*sin(alpha);
    accel_c = [x_ddt; y_ddt; zeros(1,length(x_ddt))];

    % apply the rotation
    rot = deg2rad(rot);
    R = RotX(rot(3))*RotY(rot(2))*RotZ(rot(1));
    points_c = R*points_c;
    vel_c = R*vel_c;
    accel_c = R*accel_c;
    % now move the shape to its center point
    points_c = points_c + center;

% We don't need this...
% % interpolate movement from point to point on the circle
%     % preelocate for speed
%     q_t = NaN(3,length(t));
%     qd_t = NaN(3,length(t));
%     qdd_t = NaN(3,length(t));
%     for i = 1:2:(length(t)-1)
%         % this gets the points for i and i+1
%         [q_t(:,i:i+1),qd_t(:,i:i+1),qdd_t(:,i:i+1)] = interpolTaskSpace([points_c(:,i),vel_c(:,i),accel_c(:,i)], [points_c(:,i+1),vel_c(:,i+1),accel_c(:,i+1)], [t(i),t(i+1)]);
%     end
%     % if the length of t is an odd number the last point is missing
%     [q_t(:,end-1:end),qd_t(:,end-1:end),qdd_t(:,end-1:end)] = interpolTaskSpace([points_c(:,end-1),vel_c(:,end-1),accel_c(:,end-1)], [points_c(:,end),vel_c(:,end),accel_c(:,end)], [t(end-1),t(end)]);

% Result
    q_t = points_c;     % position
    qd_t = vel_c;       % velocity
    qdd_t = accel_c;    % acceleration

end

