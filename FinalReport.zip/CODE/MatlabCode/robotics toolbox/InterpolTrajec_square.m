function [t,q_t,qd_t,qdd_t] = InterpolTrajec_square(center,a,rot,t_length,t_stepSize)
%InterpolTrajec_square
%   generates the trajectory to follow a square
%
%   input:
%       center - [x,y,z] : center point of the squarehat
%       a - [m] : length of the sides of the square
%       rot - [zRot,yRot,xRot] [°DEG] : Roll-Pitch-Yaw Angles in global frame
%       t - [s] : timelength for the whole trajectory

% get square points
    points = squareBuilder(center,a,rot);

% interpolate movement from point to point
% stop at each point -> 0 speed & 0 acceleration
    zero_vec = zeros(3,1);
    % point1 -> point2
    t1 = 0:t_stepSize:t_length/4;   % time vector
    [qt_temp,qdt_temp,qddt_temp] = interpolTaskSpace([points(:,1),zero_vec,zero_vec], [points(:,2),zero_vec,zero_vec], t1);
    q_t = qt_temp;
    qd_t = qdt_temp;
    qdd_t = qddt_temp;
    % point2 -> point3
    t2 = (t_length/4 +t_stepSize):t_stepSize:(2*t_length/4);   % time vector
    [qt_temp,qdt_temp,qddt_temp] = interpolTaskSpace([points(:,2),zero_vec,zero_vec], [points(:,3),zero_vec,zero_vec], t2);
    q_t = [q_t,qt_temp];
    qd_t = [qd_t,qdt_temp];
    qdd_t = [qdd_t,qddt_temp];
    % point3 -> point4
    t3 = (2*t_length/4 +t_stepSize):t_stepSize:(3*t_length/4);   % time vector
    [qt_temp,qdt_temp,qddt_temp] = interpolTaskSpace([points(:,3),zero_vec,zero_vec], [points(:,4),zero_vec,zero_vec], t3);
    q_t = [q_t,qt_temp];
    qd_t = [qd_t,qdt_temp];
    qdd_t = [qdd_t,qddt_temp];
    % point4 -> point1
    t4 = (3*t_length/4 +t_stepSize):t_stepSize:t_length;   % time vector
    [qt_temp,qdt_temp,qddt_temp] = interpolTaskSpace([points(:,4),zero_vec,zero_vec], [points(:,1),zero_vec,zero_vec], t4);
    q_t = [q_t,qt_temp];
    qd_t = [qd_t,qdt_temp];
    qdd_t = [qdd_t,qddt_temp];

    % complete time vector
    t = [t1,t2,t3,t4];
end

