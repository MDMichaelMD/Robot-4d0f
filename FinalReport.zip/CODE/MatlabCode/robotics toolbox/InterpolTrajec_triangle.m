function [t,q_t,qd_t,qdd_t] = InterpolTrajec_triangle(center,a,h,rot,t_length,t_stepSize)
%TRIANGLETRAJECBUILD builder for a triangle trajectory
%   builds a isoceles (2 equal sides) triangle
%
%   input:
%       center - [x,y,z] : center point of the triangle
%       a - [m] : length of the base of the triangle
%       h - [m] : heigth of the triangle
%       rot - [zRot,yRot,xRot] [°DEG] : Roll-Pitch-Yaw Angles in global frame
%       t - [s] : timelength for the whole trajectory

%   TRIANGLE
%        z↑
%    |    ^ 2
%    h   / \    → y
%    |  /_ _\    
%     1   a   3

% get triangle points
    points = triangleBuilder(center,a,h,rot);

% interpolate movement from point to point
% stop at each point -> 0 speed & 0 acceleration
    zero_vec = zeros(3,1);
    % point1 -> point2
    t1 = 0:t_stepSize:t_length/3;   % time vector
    [qt_temp,qdt_temp,qddt_temp] = interpolTaskSpace([points(:,1),zero_vec,zero_vec], [points(:,2),zero_vec,zero_vec], t1);
    q_t = qt_temp;
    qd_t = qdt_temp;
    qdd_t = qddt_temp;
    % point2 -> point3
    t2 = (t_length/3 +t_stepSize):t_stepSize:(2*t_length/3);   % time vector
    [qt_temp,qdt_temp,qddt_temp] = interpolTaskSpace([points(:,2),zero_vec,zero_vec], [points(:,3),zero_vec,zero_vec], t2);
    q_t = [q_t,qt_temp];
    qd_t = [qd_t,qdt_temp];
    qdd_t = [qdd_t,qddt_temp];
    % point3 -> point1
    t3 = (2*t_length/3 +t_stepSize):t_stepSize:t_length;   % time vector
    [qt_temp,qdt_temp,qddt_temp] = interpolTaskSpace([points(:,3),zero_vec,zero_vec], [points(:,1),zero_vec,zero_vec], t3);
    q_t = [q_t,qt_temp];
    qd_t = [qd_t,qdt_temp];
    qdd_t = [qdd_t,qddt_temp];

    % complete time vector
    t = [t1,t2,t3];
end