function R_y = RotY(theta)
%ROTY
%   rotation matrix for a rotation about the y-axis by an angle theta
    R_y = [cos(theta),  0,  sin(theta);
           0,           1,  0;
           -sin(theta), 0,  cos(theta)];
end

