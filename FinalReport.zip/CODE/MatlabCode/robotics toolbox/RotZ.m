function R_z = RotZ(theta)
%ROTZ
%   rotation matrix for a rotation about the z-axis by an angle theta
    R_z = [cos(theta), -sin(theta), 0;
           sin(theta), cos(theta),  0;
           0,          0,           1];
end

