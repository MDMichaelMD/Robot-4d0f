function xi = buildXi_prismatic(v)
%BUILDXI_PRISMATIC
%   build the screw axis xi for a prismatic joint

    xi = [v; zeros(length(v),1)];
end

