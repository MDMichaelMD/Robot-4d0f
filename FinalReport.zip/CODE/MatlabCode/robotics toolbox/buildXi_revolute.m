function xi = buildXi_revolute(omega,q)
%BUILDXI_REVOLUTE
%   build the screw axis xi for a revolute joint

    xi = [-cross(omega,q); omega];
end

