function points = circleBuilder(center, r, rot, nTurns, nPoints)
% CIRCLEBUILDER Constructs a 3D circle trajectory
%   Generates points representing a circle in 3D space based on the 
%   provided center, radius, rotations, and resolution.
%
%   INPUTS:
%       center   - [x; y; z]: Center of the circle
%       r        - [m]: Radius of the circle
%       rot      - [xRot, yRot, zRot] [°DEG]: Roll-Pitch-Yaw angles (in degrees)
%                  specifying the orientation of the circle in the global frame
%       nTurns   - Number of full rotations (2π each)
%       nPoints  - Number of points per turn
%
%   OUTPUT:
%       points   - 3xN matrix containing the points of the circle in 3D space

% Get all points on the circle

    % create an array of angles equally spaced between 0 and 2*pi
    alpha = linspace(0, nTurns*2*pi, nTurns*nPoints);

    % calculate the coordinates for each point
    points = [zeros(1,length(alpha));
              r * cos(alpha);
              r * sin(alpha)];

    % Transform circle
    % rotation
    rot = deg2rad(rot);
    R = RotX(rot(1))*RotY(rot(2))*RotZ(rot(3));
    points = R*points;
    % shift to center point
    points = points + center;

end

