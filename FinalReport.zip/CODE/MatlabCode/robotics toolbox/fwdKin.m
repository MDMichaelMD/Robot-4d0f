function transfMatrix = fwdKin(L,theta,option)
%FWDKIN get the transformation Matric for the forward kinematic using screw theory
%   default is alawys the g_st transformation

% !! All angles are in DEGREE !! 

% Check the number of inputs
if nargin < 3
    % If 'option' is not provided, set a default value
    option = 'default';
end

switch option
    case 'default'
        % if no options are given return g_st
        g_st = [-cosd(theta(1))*sind(theta(2)+theta(3)+theta(4)), -cosd(theta(1))*cosd(theta(2)+theta(3)+theta(4)),  sind(theta(1)), -cosd(theta(1))*(L(3)*sind(theta(2)+theta(3)) + L(2)*sind(theta(2)) + L(4)*sind(theta(2)+theta(3)+theta(4)));
                -sind(theta(1))*sind(theta(2)+theta(3)+theta(4)), -sind(theta(1))*cosd(theta(2)+theta(3)+theta(4)), -cosd(theta(1)), -sind(theta(1))*(L(3)*sind(theta(2)+theta(3)) + L(2)*sind(theta(2)) + L(4)*sind(theta(2)+theta(3)+theta(4)));
                 cosd(theta(2)+theta(3)+theta(4)),               -sind(theta(2)+theta(3)+theta(4)),                0,              L(1) + L(3)*cosd(theta(2)+theta(3)) + L(2)*cosd(theta(2)) + L(4)*cosd(theta(2)+theta(3)+theta(4));
                 0,                                              0,                                              0,              1];
        transfMatrix = g_st;
    case 'c'
        % transformation matrix from base to c-frame
        g_sc = [-sind(theta(2)+theta(3))*cosd(theta(1)), -cosd(theta(2)+theta(3))*cosd(theta(1)),  sind(theta(1)), -cosd(theta(1))*(L(3)*sind(theta(2)+theta(3)) + L(2)*sind(theta(2)));
                -sind(theta(2)+theta(3))*sind(theta(1)), -cosd(theta(2)+theta(3))*sind(theta(1)), -cosd(theta(1)), -sind(theta(1))*(L(3)*sind(theta(2)+theta(3)) + L(2)*sind(theta(2)));
                 cosd(theta(2)+theta(3)),               -sind(theta(2)+theta(3)),                0,              L(1) + L(3)*cosd(theta(2)+theta(3)) + L(2)*cosd(theta(2));
                 0,                                     0,                                     0,              1];
        transfMatrix = g_sc;
    case 2
        % transformation matrix from base to frame 2
        g_s2 = [-cosd(theta(1))*sind(theta(2)), -cosd(theta(1))*cosd(theta(2)),  sind(theta(1)), -L(2)*cosd(theta(1))*sind(theta(2));
                -sind(theta(1))*sind(theta(2)), -cosd(theta(2))*sind(theta(1)), -cosd(theta(1)), -L(2)*sind(theta(1))*sind(theta(2));
                 cosd(theta(2)),               -sind(theta(2)),                0,              L(1) + L(2)*cosd(theta(2));
                 0,                            0,                            0,              1];
        transfMatrix = g_s2;
    case 1
        % transformation matrix from base to frame 1
        g_s1 = [cosd(theta(1)), 0,  sind(theta(1)),  0;
                sind(theta(1)), 0, -cosd(theta(1)),  0;
                0,             1,  0,              L(1);
                0,             0,  0,              1];
        transfMatrix = g_s1;
    otherwise
        % Any other option
        error('Unrecognized option in the fwd kinematics');
end


end

