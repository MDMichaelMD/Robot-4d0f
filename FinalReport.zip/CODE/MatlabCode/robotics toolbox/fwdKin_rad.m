function transfMatrix = fwdKin_rad(l,theta,option)
%FWDKIN_RAD get the transformation Matric for the forward kinematic using screw theory
%   default is alawys the g_st transformation

% !! All angles are in RADIAN !! 

% Check the number of inputs
if nargin < 3
    % If 'option' is not provided, set a default value
    option = 'default';
end

switch option
    case 'default'
        % if no options are given return g_st
        g_st = [-cos(theta(1))*sin(theta(2)+theta(3)+theta(4)), -cos(theta(1))*cos(theta(2)+theta(3)+theta(4)),  sin(theta(1)), -cos(theta(1))*(l(3)*sin(theta(2)+theta(3)) + l(2)*sin(theta(2)) + l(4)*sin(theta(2)+theta(3)+theta(4)));
                -sin(theta(1))*sin(theta(2)+theta(3)+theta(4)), -sin(theta(1))*cos(theta(2)+theta(3)+theta(4)), -cos(theta(1)), -sin(theta(1))*(l(3)*sin(theta(2)+theta(3)) + l(2)*sin(theta(2)) + l(4)*sin(theta(2)+theta(3)+theta(4)));
                 cos(theta(2)+theta(3)+theta(4)),               -sin(theta(2)+theta(3)+theta(4)),                0,              l(1) + l(3)*cos(theta(2)+theta(3)) + l(2)*cos(theta(2)) + l(4)*cos(theta(2)+theta(3)+theta(4));
                 0,                                              0,                                              0,              1];
        transfMatrix = g_st;
    case 'c'
        % transformation matrix from base to c-frame
        g_sc = [-sin(theta(2)+theta(3))*cos(theta(1)), -cos(theta(2)+theta(3))*cos(theta(1)),  sin(theta(1)), -cos(theta(1))*(l(3)*sin(theta(2)+theta(3)) + l(2)*sin(theta(2)));
                -sin(theta(2)+theta(3))*sin(theta(1)), -cos(theta(2)+theta(3))*sin(theta(1)), -cos(theta(1)), -sin(theta(1))*(l(3)*sin(theta(2)+theta(3)) + l(2)*sin(theta(2)));
                 cos(theta(2)+theta(3)),               -sin(theta(2)+theta(3)),                0,              l(1) + l(3)*cos(theta(2)+theta(3)) + l(2)*cos(theta(2));
                 0,                                     0,                                     0,              1];
        transfMatrix = g_sc;
    case 2
        % transformation matrix from base to frame 2
        g_s2 = [-cos(theta(1))*sin(theta(2)), -cos(theta(1))*cos(theta(2)),  sin(theta(1)), -l(2)*cos(theta(1))*sin(theta(2));
                -sin(theta(1))*sin(theta(2)), -cos(theta(2))*sin(theta(1)), -cos(theta(1)), -l(2)*sin(theta(1))*sin(theta(2));
                 cos(theta(2)),               -sin(theta(2)),                0,              l(1) + l(2)*cos(theta(2));
                 0,                            0,                            0,              1];
        transfMatrix = g_s2;
    case 1
        % transformation matrix from base to frame 1
        g_s1 = [cos(theta(1)), 0,  sin(theta(1)),  0;
                sin(theta(1)), 0, -cos(theta(1)),  0;
                0,             1,  0,              l(1);
                0,             0,  0,              1];
        transfMatrix = g_s1;
    otherwise
        % Any other option
        error('Unrecognized option in the fwd kinematics');
end


end

