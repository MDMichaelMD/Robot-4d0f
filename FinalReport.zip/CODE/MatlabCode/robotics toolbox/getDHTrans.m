function A = getDHTrans(a, alpha, d, sigma)
%BUILDDHFWDTRANS 
%   builds the frame transformation matrix according to the
%   Denavit-Hartenberg (DH) convention to get the forward kinematics
    
A = [cos(sigma), -sin(sigma)*cos(alpha), sin(sigma)*sin(alpha), a*cos(sigma);
    sin(sigma), cos(sigma)*cos(alpha), -cos(sigma)*sin(alpha), a*sin(sigma);
    0, sin(alpha), cos(alpha), d;
    0, 0, 0, 1];
    
end

