function A = getDHTrans_DEGREE(a, alpha, d, sigma)
%BUILDDHFWDTRANS 
%   builds the frame transformation matrix according to the
%   Denavit-Hartenberg (DH) convention to get the forward kinematics
    
A = [cosd(sigma), -sind(sigma)*cosd(alpha), sind(sigma)*sind(alpha), a*cosd(sigma);
    sind(sigma), cosd(sigma)*cosd(alpha), -cosd(sigma)*sind(alpha), a*sind(sigma);
    0, sind(alpha), cosd(alpha), d;
    0, 0, 0, 1];
    
end

