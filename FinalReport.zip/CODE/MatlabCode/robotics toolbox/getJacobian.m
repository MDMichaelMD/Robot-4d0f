function J = getJacobian(L,theta)
%GETJACOBIAN
%   builds Jacobian Matrix

J_v = [ sind(theta(1))*(L(3)*sind((theta(2) + theta(3))) + L(2)*sind(theta(2)) + L(4)*sind((theta(2) + theta(3) + theta(4)))), -cosd(theta(1))*(L(3)*cosd((theta(2) + theta(3))) + L(2)*cosd(theta(2)) + L(4)*cosd((theta(2) + theta(3) + theta(4)))), -cosd(theta(1))*(L(3)*cosd((theta(2) + theta(3))) + L(4)*cosd((theta(2) + theta(3) + theta(4)))), -L(4)*cosd(theta(1))*cosd((theta(2) + theta(3) + theta(4)));
     -cosd(theta(1))*(L(3)*sind((theta(2) + theta(3))) + L(2)*sind(theta(2)) + L(4)*sind((theta(2) + theta(3) + theta(4)))), -sind(theta(1))*(L(3)*cosd((theta(2) + theta(3))) + L(2)*cosd(theta(2)) + L(4)*cosd((theta(2) + theta(3) + theta(4)))), -sind(theta(1))*(L(3)*cosd((theta(2) + theta(3))) + L(4)*cosd((theta(2) + theta(3) + theta(4)))), -L(4)*sind(theta(1))*cosd((theta(2) + theta(3) + theta(4)));
      0,                                                                                             -L(3)*sind((theta(2) + theta(3))) - L(2)*sind(theta(2)) - L(4)*sind((theta(2) + theta(3) + theta(4))),               -L(3)*sind((theta(2) + theta(3))) - L(4)*sind((theta(2) + theta(3) + theta(4))),               -L(4)*sind((theta(2) + theta(3) + theta(4)))];
J_w = [0, cosd(theta(1)), cosd(theta(1)), cosd(theta(1));
       0, sind(theta(1)), sind(theta(1)), sind(theta(1));
       1, 0,             0,             0];

J = [J_v; J_w];

end

