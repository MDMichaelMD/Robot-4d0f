function J = getJacobian_rad(L,theta)
%GETJACOBIAN
%   builds Jacobian Matrix

J_v = [ sin(theta(1))*(L(3)*sin((theta(2) + theta(3))) + L(2)*sin(theta(2)) + L(4)*sin((theta(2) + theta(3) + theta(4)))), -cos(theta(1))*(L(3)*cos((theta(2) + theta(3))) + L(2)*cos(theta(2)) + L(4)*cos((theta(2) + theta(3) + theta(4)))), -cos(theta(1))*(L(3)*cos((theta(2) + theta(3))) + L(4)*cos((theta(2) + theta(3) + theta(4)))), -L(4)*cos(theta(1))*cos((theta(2) + theta(3) + theta(4)));
     -cos(theta(1))*(L(3)*sin((theta(2) + theta(3))) + L(2)*sin(theta(2)) + L(4)*sin((theta(2) + theta(3) + theta(4)))), -sin(theta(1))*(L(3)*cos((theta(2) + theta(3))) + L(2)*cos(theta(2)) + L(4)*cos((theta(2) + theta(3) + theta(4)))), -sin(theta(1))*(L(3)*cos((theta(2) + theta(3))) + L(4)*cos((theta(2) + theta(3) + theta(4)))), -L(4)*sin(theta(1))*cos((theta(2) + theta(3) + theta(4)));
      0,                                                                                             -L(3)*sin((theta(2) + theta(3))) - L(2)*sin(theta(2)) - L(4)*sin((theta(2) + theta(3) + theta(4))),               -L(3)*sin((theta(2) + theta(3))) - L(4)*sin((theta(2) + theta(3) + theta(4))),               -L(4)*sin((theta(2) + theta(3) + theta(4)))];
J_w = [0, cos(theta(1)), cos(theta(1)), cos(theta(1));
       0, sin(theta(1)), sin(theta(1)), sin(theta(1));
       1, 0,             0,             0];

J = [J_v; J_w];

end

