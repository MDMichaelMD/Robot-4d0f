function omegaHat = hat3(omega)
%HAT3
%   Hat a 3x1 vector to obtain its 3x3 cross-product matrix
    omegaHat = [0 -omega(3) omega(2);
                omega(3) 0 -omega(1);
                -omega(2) omega(1) 0];
end

