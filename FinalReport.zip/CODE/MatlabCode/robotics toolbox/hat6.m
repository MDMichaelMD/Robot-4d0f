function xiHat = hat6(xi)
%HAT6
%   Hat a 6x1 vector (typically a twist) to obtain the corresponding 4x4 matrix
    
% extract omega and v
v = xi(1:3);
omega = xi(4:6);

% get omegaHat
omegaHat = hat3(omega);

% build matrix
xiHat = [omegaHat, v;
         0 0 0 0];

end

