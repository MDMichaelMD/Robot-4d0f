function [q_t,qd_t,qdd_t] = interpolTaskSpace(A, B, t)
%INTERPOLTASKSPACE
%   Interpolates 3D Cartesian position using quintic polynomials
%   based on initial and final states.

% A = [qA, vA, aA] - initial state MATRIX (pos, vel, accel) - in x,y,z
% B = [qB, vB, aB] - final state MATRIX (pos, vel, accel) - in x,y,z
% t = [t0 : stepSize : tf] - time vector includes initial and final times of movement

% dimension of the input
n = size(A,1);

% extract initial and final times
t0=t(1);
tf=t(end);

% Quintic polynomial matrix
M=[1 t0 t0^2 t0^3 t0^4 t0^5;...
   0 1 2*t0 3*t0^2 4*t0^3 5*t0^4;...
   0 0 2 6*t0 12*t0^2 20*t0^3;...
   1 tf tf^2 tf^3 tf^4 tf^5;...
   0 1 2*tf 3*tf^2 4*tf^3 5*tf^4;...
   0 0 2 6*tf 12*tf^2 20*tf^3];
% add a tiny value to prevent singular matrix warnings
epsilon = 1e-6;
M_reg = M + epsilon * eye(size(M));

% preallocate size
q_t = NaN(n,length(t));
qd_t = q_t;
qdd_t = q_t;

% loop over each dimesnion
for dim = 1:n
    % state for current dim
    state=[A(dim,1); A(dim,2); A(dim,3); B(dim,1); B(dim,2); B(dim,3)];

    % solve for c parameters in quintic polynomial
    c = M_reg\state;

    % Cartesian end effector position/vel/accel as a function of time (t)
    q_t(dim,:) = c(1) + c(2)*t + c(3)*t.^2 + c(4)*t.^3 + c(5)*t.^4 + c(6)*t.^5;
    qd_t(dim,:) = c(2) + 2*c(3)*t + 3*c(4)*t.^2 + 4*c(5)*t.^3 + 5*c(6)*t.^4;
    qdd_t(dim,:) = 2*c(3) + 6*c(4).*t + 12*c(5).*t.^2 + 20*c(6).*t.^3;

end


end

