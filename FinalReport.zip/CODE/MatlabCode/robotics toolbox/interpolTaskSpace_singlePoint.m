function q_t = interpolTaskSpace_singlePoint(A, B, t)
%INTERPOLTASKSPACE
%   Detailed explanation goes here

% A = [qA, vA, aA] - coordinate, velocity, acceleration
% B = [qB, vB, aB] - coordinate, velocity, acceleration
% t = [t0 : stepSize : tf] - time vector includes initial and final times of movement

% extract 
qA = A(1);
vA = A(2);
aA = A(3);
qB = B(1);
vB = B(2);
aB = B(3);
t0=t(1);
tf=t(end);

% interpolate for one coordinate

% Quintic polynomial matrix
A=[1 t0 t0^2 t0^3 t0^4 t0^5;...
   0 1 2*t0 3*t0^2 4*t0^3 5*t0^4;...
   0 0 2 6*t0 12*t0^2 20*t0^3;...
   1 tf tf^2 tf^3 tf^4 tf^5;...
   0 1 2*tf 3*tf^2 4*tf^3 5*tf^4;...
   0 0 2 6*tf 12*tf^2 20*tf^3];
State=[qA;vA;aA;qB;vB;aB];

% solve for c parameters in quintic polynomial
c = A\State;

% Cartesian end effector position/vel/accel as a function of time (t)
q_t=c(1)+c(2)*t+c(3)*t_.^2+c(4)*t_.^3+c(5)*t_.^4+c(6)*t_.^5;
% qd_t=c(2)+2*c(3)*t+3*c(4)*t_.^2+4*c(5)*t_.^3+5*c(6)*t_.^4;
% qdd_t=2*c(3)+6*c(4).*t+12*c(5).*t_.^2+20*c(6).*t_.^3;

end

