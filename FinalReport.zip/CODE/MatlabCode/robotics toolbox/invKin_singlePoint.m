function theta = invKin_singlePoint(ArmLengths,ToolPos,ToolOrientation)
%FWDKIN Summary of this function goes here
%   Input: position as well as orientation
%       (because of the physical limitations of the robot only a certain aspect of the orientation can be applied;
%       only rotation around z-axis in the tool frame can be applied; other angles will be ignored)
% 
%   Output: the idea is to find the motor angles (thetas) that can directly be forwared to the robot.
%       Therefore the inv kinematics have to be applied.
%       Also needs to respect the limit of the robot and checks if it even is possible to reach the given position


% !! All angles are in DEGREE !! 

% disp(ToolPos)

% robot limits (physical restrains)
% [min rotation angle, max rotation angle]
% !!! [°DEG] !!!
% add a buffer to the actual physical limitations
motorlim_buffer = 3;    % [°DEG]
theta1_lim = [-152, 128] + motorlim_buffer*[1,-1];   % base motor
theta2_lim = [-110, 110] + motorlim_buffer*[1,-1];   % first arm motor
theta3_lim = [-122, 122] + motorlim_buffer*[1,-1];    % middle arm motor
theta4_lim = [-138, 138] + motorlim_buffer*[1,-1];     % final tool motor
theta_lim = [theta1_lim; theta2_lim; theta3_lim; theta4_lim]; % put together
% actual motor limits
% M1: 28 - 308
% M2: 70 - 290
% M3: 58 - 302
% M4: 42 - 318

% With the current design most of these are 0.
% The only proper dimensions needed are the arm lengths

% CALCULATIONS

% get first motor orientation
theta(1) = atan2d(ToolPos(2),ToolPos(1));

% get the point c (Position of the fourth motor)
c = [ToolPos(1) - ArmLengths(4)*cosd(ToolOrientation)*cosd(theta(1));
     ToolPos(2) - ArmLengths(4)*cosd(ToolOrientation)*sind(theta(1));
     ToolPos(3) + ArmLengths(4)*sind(ToolOrientation)];

% Check if the point c is reachable
% (ignoring theta lim for now; only testing if we are within the arm reach)

% distance of c to the origin of frame 2
d = sqrt(c(1)^2 + c(2)^2 + (c(3)-ArmLengths(1))^2);

if d > (ArmLengths(2)+ArmLengths(3))
    error("Point is outside of the reachable space of the robot arm. Aborting inverse kinematics.");

else % if not we can continue

% helper parameter
% D = (ArmLengths(2)^2 + ArmLengths(3)^2 - c(1)^2 - c(2)^2 - (c(3)-ArmLengths(1))^2)/(2*ArmLengths(2)*ArmLengths(3));
D = -(ArmLengths(2)^2 + ArmLengths(3)^2 - c(1)^2 - c(2)^2 - (c(3)-ArmLengths(1))^2)/(2*ArmLengths(2)*ArmLengths(3));    % why the "-"?? Without it this breaks
% D=(x_t.^2+y_t.^2-L1^2-L2^2)/(2*L1*L2);

% calculate theta3
theta(3) = atan2d(-sqrt(1-D^2), D);    % replace - with + for elbow down solution
% u2=atan2(sqrt(1-D.^2),D); %joint angle (link 1)

% calculate theta2
theta(2) = atan2d(-sqrt(c(1)^2 + c(2)^2), c(3)-ArmLengths(1)) - atan2d(ArmLengths(3)*sind(theta(3)), ArmLengths(2) + ArmLengths(3)*cosd(theta(3)));%
% u1=atan2(y_t,x_t)-atan2(L2*sin(u2),L1+L2*cos(u2)); %joint angle (link 2)

% calculate theta4
% theta(4) = ToolOrientation - theta(2) - theta(3);
theta(4) = -ToolOrientation - 90 - theta(2) - theta(3);

end

% we have a solution for all motor orientations now

% check if they are reachable (within limits)
theta_unreachable = NaN(length(theta_lim),1);
for i = 1:length(theta)
    if theta_lim(i,1) <= theta(i) && theta(i) <= theta_lim(i,2)
        theta_unreachable(i) = false;
    else
        fprintf("Theta%d %.1f is not within %.1f <= theta(%d) <= %.1f. \n", i, theta(i), theta_lim(i,1), i, theta_lim(i,2));
        theta_unreachable(i) = true;
    end
end

% Throw out an error if at least one theta is not reachable
if theta_unreachable(1) || theta_unreachable(2) || theta_unreachable(3) || theta_unreachable(4)
    warning("Not all motor positions are reachable.")
end

end

