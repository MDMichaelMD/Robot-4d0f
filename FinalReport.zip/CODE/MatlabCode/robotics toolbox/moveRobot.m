function moveRobot(ArmLengths,MotorPos,timestep,GoalTraj)
%MOVEROBOT
%   uses the screw theory to get the forward kinematics needed for plotting the robot
%   animate movement using all given motor positions

% Arm length - constant
% [ground plane box - rotation axis motor 2; RotAx Motor 2 - RotAx Motor 3; RotAx Motor 3 - RotAx Motor 4; RotAx Motor 4 - Pen Tip]

% The position of the motors are the only variables needed to determine its position
% MotorPos = [theta1, theta2, theta3, theta4] < all four motor positions !! [DEG] !!

    % # DOF
    n = size(MotorPos,1);
    % # of timesteps
    n_ts = size(MotorPos,2);
    
    % function settings
    PlotSettings.linewidth = 2;
    PlotSettings.fontSize = 12;
    PlotSettings.plotOrigin = true;
    PlotSettings.originLabel = true;
    PlotSettings.axesScale = 0.1;
    PlotSettings.axesLabels = true;

    % function parameters
    armWidth = 4;  % used for plotting as a line
    jointSize = 60; % size of the joint points
    linksColor = [60,60,60]/255; % RGB color (grayish black)
    jointColor = [255,130,0]/255; % RGB color (orange)


% Get all joint positions over the length of MotorPos

    % matrices to store all joint positions
    joint1 = NaN(3,n_ts);
    joint2 = NaN(3,n_ts);
    joint3 = NaN(3,n_ts);
    toolpoint = NaN(3,n_ts);

    % initialize frame parameters represented in their own frame
    origin_base = [0;0;0];
    x_base = [1;0;0];
    y_base = [0;1;0];
    z_base = [0;0;1];

    for i = 1:n_ts

        % get the current motor positions
        theta = MotorPos(:,i);

        % get all transformation matrices to the robot base s
        g_st = fwdKin(ArmLengths,theta);
        g_s1 = fwdKin(ArmLengths,theta,1);
        g_s2 = fwdKin(ArmLengths,theta,2);
        g_sc = fwdKin(ArmLengths,theta,'c');
        
        % get position of the joints
        joint1_pos = g_s1*[origin_base;1]; % add a 1 since it's a point
        joint1(:,i) = joint1_pos(1:3);
        joint2_pos = g_s2*[origin_base;1]; % add a 1 since it's a point
        joint2(:,i) = joint2_pos(1:3);
        joint3_pos = g_sc*[origin_base;1]; % add a 1 since it's a point
        joint3(:,i) = joint3_pos(1:3);
        toolpoint_pos = g_st*[origin_base;1]; % add a 1 since it's a point
        toolpoint(:,i) = toolpoint_pos(1:3);

    end

    
% Robot animation

    % Initialize the figure
    fig1 = figure('units','normalized','outerposition',[0 0 1 1]);
    hold on
    axis equal
    grid on
    view([-40 30])
    % this is the box we want to look at
    xlim([-0.1, 0.5]);
    ylim([-0.4, 0.4]);
    zlim([0,0.6]);

    % first frame of the animation

    % initialize the elements of the animation

    % base frame (static)
    plotFrame(origin_base, [x_base,y_base,z_base], 's', PlotSettings)

    if nargin > 3
        % goal trajectory
        plot3(GoalTraj(1,:),GoalTraj(2,:),GoalTraj(3,:),'b-o');
    end

    % plot the robot as a line (links) and dots (joints)
    robot = [origin_base,joint1(:,1),joint2(:,1),joint3(:,1),toolpoint(:,1)];
    robLine_Plot = plot3(robot(1,:),robot(2,:),robot(3,:),'Color',linksColor, 'LineWidth', armWidth);
    joint1_Plot = scatter3(joint1(1,1), joint1(2,1), joint1(3,1), jointSize, 'filled', 'MarkerFaceColor', jointColor);
    joint2_Plot = scatter3(joint2(1,1), joint2(2,1), joint2(3,1), jointSize, 'filled', 'MarkerFaceColor', jointColor);
    joint3_Plot = scatter3(joint3(1,1), joint3(2,1), joint3(3,1), jointSize, 'filled', 'MarkerFaceColor', jointColor);
    
    % plot the End Effector position
    toolpoint_Plot = plot3(toolpoint(1,1),toolpoint(2,1),toolpoint(3,1),'r-*');

    % save the first frame to the video
    % if saveVid_Motion
    %     vidFrames_Motion = getframe(ax);
    % end

    % main animation loop
    for frame = 2:n_ts
        
        % update the robot representation
        robot = [origin_base,joint1(:,frame),joint2(:,frame),joint3(:,frame),toolpoint(:,frame)];
        set(robLine_Plot,'XData',robot(1,:),'YData',robot(2,:),'ZData',robot(3,:));    % update line
        set(joint1_Plot,'XData',joint1(1,frame),'YData',joint1(2,frame),'ZData',joint1(3,frame));    % update joints
        set(joint2_Plot,'XData',joint2(1,frame),'YData',joint2(2,frame),'ZData',joint2(3,frame));
        set(joint3_Plot,'XData',joint3(1,frame),'YData',joint3(2,frame),'ZData',joint3(3,frame));
        
        % update the EE path
        set(toolpoint_Plot,'XData',toolpoint(1,1:frame),'YData',toolpoint(2,1:frame),'ZData',toolpoint(3,1:frame));
    
        % Force MATLAB to update the figure 
        drawnow
        pause(timestep)
        
        % save the current frame
        % if saveVid_Motion
        %     vidFrames_Motion = [vidFrames_Motion, getframe(ax)];
        % end

    end
    
    % create a video file
    % if saveVid_Motion
    %     video_filename = fileName;  % uses the filename of the MPC data file
    %     video_pathname = 'export/';
    %     videoFile_Motion = VideoWriter([video_pathname,video_filename,'.mp4'], 'MPEG-4');
    %     %videoFile = VideoWriter([video_pathname,video_filename,'.avi']);
    %     videoFile_Motion.FrameRate = 1/Ts_picture;
    %     videoFile_Motion.Quality = 100;
    % 
    %     % write all frames to the video file
    %     open(videoFile_Motion);
    %     for k=1:length(vidFrames_Motion)
    %         writeVideo(videoFile_Motion,vidFrames_Motion(k));
    %     end
    %     close(videoFile_Motion);
    % end
    
end

