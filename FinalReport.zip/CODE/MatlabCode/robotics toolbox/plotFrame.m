function plotFrame(origin,Axes,index,plotSettings)
%PLOTFRAME
%   plots a coordinate frame

    % general settings
    linewidth = plotSettings.linewidth;
    fontSize = plotSettings.fontSize;
    axesScale = plotSettings.axesScale;
    plotOrigin = plotSettings.plotOrigin;   % true/false
    originLabel = plotSettings.originLabel; % true/false
    axesLabels = plotSettings.axesLabels;   % true/false
    
    % function parameters
    pointSize = 40;
    maxHeadSize = axesScale*8;
    labelAxis_offsetFactor = 1.2;
    axesNames = {'x_', 'y_', 'z_'};
    axesColors = {'r', 'g', 'b'};   % {x-axis, y-axis, z-axis}    

    % get length of on axis (x/y/z should all be the same)
    axisLength = norm(Axes(:,1))*axesScale;

    % scale Axes
    Axes = axesScale * Axes;
    
    hold on

    % plot axes
    for i=1:3
        quiver3(origin(1), origin(2), origin(3), Axes(1,i), Axes(2,i), Axes(3,i), 0, axesColors{i}, 'LineWidth', linewidth, 'MaxHeadSize', maxHeadSize);
    end
    
    % plot origin
    if plotOrigin
        scatter3(origin(1), origin(2), origin(3), pointSize, 'filled', 'MarkerFaceColor', 'black');
    end

    % add label to origin
    if originLabel
        % text(origin(1)-axisLength/4, origin(2)-axisLength/4, origin(3)-axisLength/4, ['O_',index], 'FontSize', fontSize, 'Color', 'black');
        text(origin(1)-axisLength/8, origin(2)-axisLength/8, origin(3)-axisLength/8, index, 'FontSize', fontSize, 'Color', 'black');
    end

    % add labels to each axis
    if axesLabels
        for i=1:3
        text(origin(1)+labelAxis_offsetFactor*Axes(1,i), origin(2)+labelAxis_offsetFactor*Axes(2,i), origin(3)+labelAxis_offsetFactor*Axes(3,i), ...
            [axesNames{i},index], 'FontSize', fontSize, 'Color', axesColors{i});
        end
   
    end
end

