function plotRobot_DH(RobotPara,MotorPos,PlotSettings)
%PLOTROBOT_DH
%   uses the DH table to get the forward kinematics needed for plotting the
%   robot

% Since the robot parameters are static they could be removed as variables from the equation. 
% (TransMatrices_symbolic uses RobotPara to build all transformation
% matrices) - not active atm
% RobotPara = [a(), alpha(), d()]   < all fixed robot parameters according to the DH convention
%       a() = [a1; a2; a3; a4]
%       alpha() = [alpha1; alpha2; alpha3; alpha4]
%       d() = [d1; d2; d3; d4]

% The position of the motors are the only variables needed to determine its position
% MotorPos = [theta1, theta2, theta3, theta4] < all four motor positions !! [DEG] !!

    % extract robot parameters
    a = RobotPara(:,1);     % [m]
    alpha = RobotPara(:,2); % [°]
    d = RobotPara(:,3);     % [m]

    % # DOF
    n = length(MotorPos);
    
    % function settings
    PlotSettings.linewidth = 2;
    PlotSettings.fontSize = 12;
    PlotSettings.plotOrigin = true;
    PlotSettings.originLabel = true;
    PlotSettings.axesScale = 0.05;
    PlotSettings.axesLabels = true;

    % function parameters
    arm_width = 4;  % used for plotting as a line
    % these are all for the cylindrical representation (radius & height of the cylinders)
    n_cyl = 32;   % # of equally spaced points around its circumference
    linksR = [0.02, 0.01, 0.01, 0.01, 0.01];  % radius of [base0, arm1, arm2, arm3, arm4]
    linksH = [0.01,d(1),a(2),a(3),a(4)]; % base height + l of the arms are included in the RobotPara 
    linksColor = [60,60,60]/255; % RGB color (grayish black)
    jointR = 0.013; % [m]
    jointH = 0.03; % [m]
    jointColor = [255,130,0]/255; % RGB color (orange)
    % cylColor = [1,0,0]; % RGB color
    

    % get all A transf matrices
    A1 = getDHTrans_DEGREE(a(1), alpha(1), d(1), MotorPos(1));
    A2 = getDHTrans_DEGREE(a(2), alpha(2), d(2), MotorPos(2));
    A3 = getDHTrans_DEGREE(a(3), alpha(3), d(3), MotorPos(3));
    A4 = getDHTrans_DEGREE(a(4), alpha(4), d(4), MotorPos(4));
    
    % get all H transformation matrices to the robot base 0
    H01 = A1;
    H02 = H01 * A2;
    H03 = H02 * A3;
    H04 = H03 * A4;
    H = [H01; H02; H03; H04];   % each H_xx is a 4x4 matrix -> stack in H(16, 4)

% Frames
    % initialize frame parameters represented in their own frame
    origin_base = [0;0;0];
    x_base = [1;0;0];
    y_base = [0;1;0];
    z_base = [0;0;1];
    % no conversion needed for frame 0
    
    % build all other  frames
    for s=1:n

        % extract H for the current frame s to base 0
        H_current = H((4*(s-1)+1):(4*s),:);

        % origin; add a 1 since it's a point
        origin(:,s) = H_current*[origin_base;1];

        % axes; add a 0 since it's a vector
        x_axis(:,s) = H_current*[x_base;0];
        y_axis(:,s) = H_current*[y_base;0];
        z_axis(:,s) = H_current*[z_base;0];        

    end

    % extract usable data
    origin = origin(1:3,:);
    x_axis = x_axis(1:3,:);
    y_axis = y_axis(1:3,:);
    z_axis = z_axis(1:3,:);

    % add frame 0
    origin = [origin_base ,origin];
    x_axis = [x_base ,x_axis];
    y_axis = [y_base ,y_axis];
    z_axis = [z_base ,z_axis];

% cylindrical representation
% this is the way more complex but cooler version building the robot with cylinders

    % BASE
    % -> build the cylinder in its reference frame
    % [baseCyl_X, baseCyl_Y, baseCyl_Z] = cylinder(baseR,n_cyl);   % create a zylinder with height 1 in z
    % baseCyl_Z = baseH * baseCyl_Z;  % adjust height
    % baseCyl = [baseCyl_X; baseCyl_Y; baseCyl_Z];  % store it in one 6x(n_cyl+1) matrix [x[bottom;top]; y[b;t]; z[b;t]]
    % -> no transformation needed since the base is in frame0
    
    % LINKS (BASE + ARM)
    linksCyl = NaN(6*(n+1),n_cyl+1); % initialize empty matrix
    for i=0:n
        index = i+1; % shift, e.q. Joint0 is joint(1) since MATLAB can't handle index 0
        % -> build the cylinder in its reference frame
        [linksCyl_X, linksCyl_Y, linksCyl_Z] = cylinder(linksR(index),n_cyl);   % create a zylinder with height 1 in z
        linksCyl_Z = linksH(index) * linksCyl_Z;  % adjust height
        % linksCyl_Z = -linksCyl_Z;   % since all arms go in the opposite direction of the xAxis
        
        if i==0 % base
        % -> no transformation needed for the base since it is in frame0
            linksCyl(1:6,:) = [linksCyl_X; linksCyl_Y; linksCyl_Z];
        else % arm
        % -> transform to base0
            % put all cylinder points in one matrix
            [nRows, nCols] = size(linksCyl_X);
            linksCyl_pts = [linksCyl_X(:)'; linksCyl_Y(:)'; linksCyl_Z(:)'; ones(1, nRows*nCols)];  % add ones since these are points
            % all zylinders are along z. Rotate them according to their actual orientation
            if i == 1
                % rotate the cylinder around y to go into -x instead of z direction
                T = eye(4);
                T(1:3,1:3) = rotx(90);
                linksCyl_pts = T * linksCyl_pts;
            else
                % rotate the cylinder around y to go into -x instead of z direction
                T = eye(4);
                T(1:3,1:3) = roty(-90);
                linksCyl_pts = T * linksCyl_pts;
            end
            % extract H for the current frame i to base 0
            H_current = H((4*(i-1)+1):(4*i),:);
            % apply transformation to the points
            linksCyl_transPts = H_current * linksCyl_pts;
            % extract transformed X, Y, Z
            linksCyl_X_trans = reshape(linksCyl_transPts(1, :), nRows, nCols);
            linksCyl_Y_trans = reshape(linksCyl_transPts(2, :), nRows, nCols);
            linksCyl_Z_trans = reshape(linksCyl_transPts(3, :), nRows, nCols);
            % store it in one 6x(n_cyl+1) matrix [x[bottom;top]; y[b;t]; z[b;t]]
            linksCyl(6*(index-1)+1:6*index,:) = [linksCyl_X_trans;linksCyl_Y_trans;linksCyl_Z_trans];
        end
    end
    
    % JOINTS
    jointCyl = NaN(6*n,n_cyl+1); % initialize empty matrix
    % -> build the cylinder in its reference frame (they are all the same)
    [jointCyl_X, jointCyl_Y, jointCyl_Z] = cylinder(jointR,n_cyl);   % create a zylinder with height 1 in z
    jointCyl_Z = jointH * jointCyl_Z;  % adjust height
    % store the first joint since it doesn't need shifting bc it is in frame0
    jointCyl(1:6,:) = [jointCyl_X; jointCyl_Y; jointCyl_Z];
    % shift the cylinder now so its center is in the x-y-plane
    jointCyl_Z = jointCyl_Z - 0.5*jointH; % *ones(length(jointCyl_Z))    
    % -> transform to base0
    % go through the rest of the joints (joint i is in the origin of frame i-1)
    for i=2:n
        % put all cylinder points in one matrix
        [nRows, nCols] = size(jointCyl_X);
        jointCyl_pts = [jointCyl_X(:)'; jointCyl_Y(:)'; jointCyl_Z(:)'; ones(1, nRows*nCols)];  % add ones since these are points
        % extract H for the frame i-1 to base 0
        H_current = H((4*(i-2)+1):(4*(i-1)),:);
        % apply transformation to the points
        jointCyl_transPts = H_current * jointCyl_pts;
        % extract transformed X, Y, Z
        jointCyl_X_trans = reshape(jointCyl_transPts(1, :), nRows, nCols);
        jointCyl_Y_trans = reshape(jointCyl_transPts(2, :), nRows, nCols);
        jointCyl_Z_trans = reshape(jointCyl_transPts(3, :), nRows, nCols);
        % store it in one 6x(n_cyl+1) matrix [x[bottom;top]; y[b;t]; z[b;t]]
        jointCyl(6*(i-1)+1:6*i,:) = [jointCyl_X_trans;jointCyl_Y_trans;jointCyl_Z_trans];
    end

    
% Robot Plot
    figure;
    hold on
    axis equal
    grid on
    view([45 45])

    % plot as one line
    plot3(origin(1,:),origin(2,:),origin(3,:),'black-o', 'LineWidth', arm_width)

% cylinder robot model
    % BASE
    % surf(baseCyl(1:2,:),baseCyl(3:4,:),baseCyl(5:6,:),'FaceColor', linksColor, 'EdgeColor', 'none');
    % fill3(baseCyl(1,:),baseCyl(3,:),baseCyl(5,:),linksColor);
    % fill3(baseCyl(2,:),baseCyl(4,:),baseCyl(6,:),linksColor);
    % LINKS (BASE + ARM)
    for i=0:6:6*n
        surf(linksCyl(i+1:i+2,:),linksCyl(i+3:i+4,:),linksCyl(i+5:i+6,:),'FaceColor', linksColor, 'EdgeColor', 'none');
        fill3(linksCyl(i+1,:),linksCyl(i+3,:),linksCyl(i+5,:),linksColor);
        fill3(linksCyl(i+2,:),linksCyl(i+4,:),linksCyl(i+6,:),linksColor);
    end
    % JOINTS
    for i=0:6:6*n-1
        surf(jointCyl(i+1:i+2,:),jointCyl(i+3:i+4,:),jointCyl(i+5:i+6,:),'FaceColor', jointColor, 'EdgeColor', 'none');
        fill3(jointCyl(i+1,:),jointCyl(i+3,:),jointCyl(i+5,:),jointColor);
        fill3(jointCyl(i+2,:),jointCyl(i+4,:),jointCyl(i+6,:),jointColor);
    end

    % plot all frames
    for i=0:n
        index = i+1;
        if PlotSettings.EnabledFrames(index)
            plotFrame(origin(:,index), [x_axis(:,index), y_axis(:,index), z_axis(:,index)], num2str(i), PlotSettings)
        end
    end

end

