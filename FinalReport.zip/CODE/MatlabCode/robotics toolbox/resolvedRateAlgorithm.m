function [q_t,p_t] = resolvedRateAlgorithm(q0,GoalTraj,ArmLengths,options)
%RESOLVEDRATEALGORITHM
%   controls the robot movement by finding joint values to reach the goal position(s)
%
%       q0 [DEG] : joint values
%       GoalTraj [m] : trajectory the robot should follow

% Settings
iter = options.iter; % max amount of iterations
dt = options.dt; % timestep of the RR-algorithm [s]
p_error_Tol = options.p_error_Tol; % [m] the acceptable tolerance is 1mm
v = options.v;   % [m/s] the speed the robot travels at

% define robot from DH table
L1 = Link('a', 0, 'alpha', pi/2, 'd', ArmLengths(1));
L2 = Link('a', ArmLengths(2), 'alpha', 0, 'd', 0, 'offset', pi/2);
L3 = Link('a', ArmLengths(3), 'alpha', 0, 'd', 0);
L4 = Link('a', ArmLengths(4), 'alpha', 0, 'd', 0);
bot = SerialLink([L1 L2 L3 L4], 'name', 'FinalProjRobot');

% robot limits (physical restrains)
% [min rotation angle, max rotation angle]
% !!! [°DEG] !!!
% add a buffer to the actual physical limitations
motorlim_buffer = 3;    % [°DEG]
q1_lim = [-152, 128] + motorlim_buffer*[1,-1];   % base motor
q2_lim = [-110, 110] + motorlim_buffer*[1,-1];   % first arm motor
q3_lim = [-122, 122] + motorlim_buffer*[1,-1];    % middle arm motor
q4_lim = [-138, 138] + motorlim_buffer*[1,-1];     % final tool motor
q_lim = [q1_lim; q2_lim; q3_lim; q4_lim]; % put together
% actual motor limits (DEG)
% M1: 28 - 308
% M2: 70 - 290
% M3: 58 - 302
% M4: 42 - 318


% Initialization

    % % preelocate for speed
    % % EE pos
    % p_j = NaN(3,length(theta));
    % % joint values
    % q_j = NaN(3,length(theta));


% Resolved rate Algorithm
    
    % initial joint values and first position
    q0 = deg2rad(q0); % change to RAD
    q = q0;
    [T, ~] = bot.fkine(q);
    p_c = T.t;
    
    % for storing all values
    q_t = q0; % joint values
    p_t = p_c; % EE pos
    
    for j = 1:size(GoalTraj,2) % loop through all targets
        % fprintf('Step %d: \n', j)
    
        % the positon we want to reach
        p_d = GoalTraj(:,j);
    
        for k = 1:iter + 1 % solve for each target
    
            % get the error vector between the desired and current positon
            p_error = p_d - p_c;
            % length of that vector -> abs distance between the two positions
            p_error_norm = norm(p_error);
    
            % check if that error is smaller than the accepted tolerance 
            % or we are reaching the iterations limit
            if p_error_norm < p_error_Tol
                % disp('Exiting. Reached target within tolerance')
                break
            elseif k == iter+1
                fprintf('Step %d: ', j)
                disp('Exiting. Max iteration number exceeded')
                break
            end
            
            % the desired velocity of the EE is a movement along the error vector
            pdt_d = v * p_error/p_error_norm;
    
            % get the jacobian
            % J = getJacobian_rad(ArmLengths,q);
            % [T, T_all] = bot.fkine(q);
            % R_all = T_all.R;
            % R = T.R;
            J = bot.jacob0(q);
            J = J(1:3,:); % we only care about the position, not the orientation

            
            % J is square but it is invertible?
            % if det(J) < 1e-3
            %     % disp('J is singular')
            %     % det is close to 0 and therefore not invertible
            %     J = J + eye(size(J,1))*1e-3; % add small value
            % end
            % get pseudo inverse
            min_singval_J = min(svd(J));
            if min_singval_J < 1e-3
                singular = true;
                pinvJ = J'/(J*J' + (1e-3)*eye(size(J,1))); % singularity robust pseudo-inverse
            else
                singular = false;
                pinvJ = pinv(J);
            end
            
            % now get the desired movement of the joints
            % qdt_d = J\pdt_d;    % this is the same as using the inverse of J
            qdt_d = pinvJ * pdt_d;
    
    
            % update q for one timestep
            q = q + qdt_d * dt;
            % update new position
            [T, ~] = bot.fkine(q);
            p_c = T.t;
            % frame = fwdKin_rad(q,ArmLengths);
            % p_c = frame(1:3,4);
            
            % store all q values dependent of t
            q_t = [q_t, q];

            % store EE pos
            p_t = [p_t, p_c];
        end
        % store
        % p_j(:,j) = p_c;
        % q_j(:,j) = q;
    end

    % change back to DEG
    q_t = rad2deg(q_t);

    % check if they are reachable (within limits)
    q_unreachable = NaN(length(q_lim),1);
    for i = 1:size(q_t,1)
        if q_lim(i,1) <= min(q_t(i,:)) && max(q_t(i,:)) <= q_lim(i,2)
            q_unreachable(i) = false;
        else
            fprintf("q%d [%.1f, %.1f] is not within %.1f <= q(%d) <= %.1f. \n", i, min(q_t(i,:)), max(q_t(i,:)), q_lim(i,1), i, q_lim(i,2));
            q_unreachable(i) = true;
        end
    end
    
    % Throw out a warning if at least one q is not reachable
    if q_unreachable(1) || q_unreachable(2) || q_unreachable(3) || q_unreachable(4)
        warning("Not all motor positions are reachable.")
    end

end

