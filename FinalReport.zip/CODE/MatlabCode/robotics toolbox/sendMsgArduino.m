function SerialMsg = sendMsgArduino(arduino, theta, dt)
%SENDMSGARDUINO
%   sends a message containig the motor angles to the arduino

%   MSG format
%   <timestep|theta1(time1),theta2(time1),theta3(time1),theta4(time1);theta1(time2),theta2(time2),...>
%   timestep dt: the time length between time1 and time2 (as well as all other time steps)
%   theta: motor angle [DEG]

    % max amount of characters
    maxCharLength = 1200;    % should be the same on the arduino

    % to handle the angle to Steps conversion
    StepsPerRevolution= [200, 200, 200, 2000]; % steps per revolution for the motors
    GearboxRatio = [5, 5, 1, 1]; % amount of motor rotations to get one rotation after gearbox (reduction ratio of the gearbox)
    MicroStepps = [8, 2, 4, 1]; % amount of steps per full step
    ChangeDirection = [1, 1, 1, 1]; % use this to change the direction of a stepper

    % calc StepPosition for all four motors
    StepPos = zeros(size(theta));
    for k = 1:size(theta,1)
        StepPos(k,:) = round(ChangeDirection(k)*GearboxRatio(k)*MicroStepps(k) * StepsPerRevolution(k) * theta(k,:)/360.0);
    end

    % Build the msg
    SerialMsg = '';
    for i = 1:size(StepPos,2)
        if i == size(StepPos,2)
            % last motor angle set
            SerialMsg = [SerialMsg, sprintf('%d,%d,%d,%d', StepPos(1,i),StepPos(2,i),StepPos(3,i),StepPos(4,i))];
        else
            SerialMsg = [SerialMsg, sprintf('%d,%d,%d,%d', StepPos(1,i),StepPos(2,i),StepPos(3,i),StepPos(4,i)), ';'];
        end
    end
    SerialMsg = ['<', num2str(dt), '|', SerialMsg, '>'];

    % send out a warning if msg is too long
    if length(SerialMsg) >maxCharLength
        warning('The serial message is too long for the arduino to process.');
        fprintf('SerialMsg Length: %d \n',length(SerialMsg));
    end

    % Send the angles as a serial msg to the arduino
    writeline(arduino, SerialMsg);

end

