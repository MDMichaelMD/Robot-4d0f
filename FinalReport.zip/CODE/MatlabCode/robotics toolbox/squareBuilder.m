function points = squareBuilder(center,a,rot,n)
%SQUARETRAJECBUILD
%   builds a square based from its center point
%
%   INPUTS:
%       center   - [x; y; z]: Center of the square
%       a        - [m]: Length of the sides of the square
%       rot      - [xRot, yRot, zRot] [°DEG]: Roll-Pitch-Yaw angles (in degrees)
%                  specifying the orientation of the square in the global frame
%       n        - (optional) : get n intermediate points between corners

%   SQUARE [0,0,0] orientation
%
%        z↑
%      2     3
%        ⌜‾⌝ 
%        ⌞_⌟      → y
%      1     4point1 = R*point1;

% Get all corner points
    % square corners
    point1 = [0; - a/2; - a/2]; % (bottom,left)
    point2 = [0; - a/2; a/2];   % (top,left)
    point3 = [0; a/2; a/2];     % (top,right)
    point4 = [0; a/2; - a/2];   % (bottom,right)
    % apply the rotation
    rot = deg2rad(rot);
    R = RotX(rot(1))*RotY(rot(2))*RotZ(rot(3));
    point1 = R*point1;
    point2 = R*point2;
    point3 = R*point3;
    point4 = R*point4;
    % now move it to its center point
    point1 = point1 + center;
    point2 = point2 + center;
    point3 = point3 + center;
    point4 = point4 + center;
    
    % put all corner points together
    points = [point1,point2,point3,point4,point1];

    % option to get n linear interpolated points between the corner points
    if nargin > 3
        % if n should add 1 point we need at least 3 points (corner1, middle, corner2)
        n = n+2;

        % Linearly interpolate between each corner
        % 1 -> 2
        points12 = [linspace(points(1,1), points(1,2), n);
                    linspace(points(2,1), points(2,2), n);
                    linspace(points(3,1), points(3,2), n)];
        % 2 -> 3
        points23 = [linspace(points(1,2), points(1,3), n);
                    linspace(points(2,2), points(2,3), n);
                    linspace(points(3,2), points(3,3), n)];
        % 3 -> 4
        points34 = [linspace(points(1,3), points(1,4), n);
                    linspace(points(2,3), points(2,4), n);
                    linspace(points(3,3), points(3,4), n)];
        % 4 -> 1
        points41 = [linspace(points(1,4), points(1,1), n);
                    linspace(points(2,4), points(2,1), n);
                    linspace(points(3,4), points(3,1), n)];

        % put all logether
        points = [points12,points23(:,2:end),points34(:,2:end),points41(:,2:end)];
    end

end

