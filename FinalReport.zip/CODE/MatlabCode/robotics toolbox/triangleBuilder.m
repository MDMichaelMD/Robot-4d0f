function points = triangleBuilder(center,a,h,rot,n)
%triangleBuilder
%   builds a isoceles (2 equal sides) triangle
%
%   INPUTS:
%       center   - [x; y; z]: Center of the triangle
%       a        - [m]: Length of the base of the triangle
%       h        - [m] : Heigth of the triangle
%       rot      - [xRot, yRot, zRot] [°DEG]: Roll-Pitch-Yaw angles (in degrees)
%                  specifying the orientation of the triangle in the global frame
%       n        - (optional) : get n intermediate points between corners

%   TRIANGLE
%        z↑
%    |    ^ 2
%    h   / \    → y
%    |  /_ _\    
%     1   a   3

% get all corner points
    % triangle corners
    point1 = [0; -a/2; -h/2];   % (bottom,left)
    point2 = [0; 0; h/2];       % (top)
    point3 = [0; a/2; -h/2];    % (bottom,right)
    % apply the rotation
    rot = deg2rad(rot);
    R = RotX(rot(1))*RotY(rot(2))*RotZ(rot(3));
    point1 = R*point1;
    point2 = R*point2;
    point3 = R*point3;
    % now move it to its center point
    point1 = point1 + center;
    point2 = point2 + center;
    point3 = point3 + center;

    % put all points together
    points = [point1,point2,point3,point1];

    % option to get n linear interpolated points between the corner points
    if nargin > 4
        % if n should add 1 point we need at least 3 points (corner1, middle, corner2)
        n = n+2;

        % Linearly interpolate between each corner
        % 1 -> 2
        points12 = [linspace(points(1,1), points(1,2), n);
                    linspace(points(2,1), points(2,2), n);
                    linspace(points(3,1), points(3,2), n)];
        % 2 -> 3
        points23 = [linspace(points(1,2), points(1,3), n);
                    linspace(points(2,2), points(2,3), n);
                    linspace(points(3,2), points(3,3), n)];
        % 3 -> 1
        points31 = [linspace(points(1,3), points(1,1), n);
                    linspace(points(2,3), points(2,1), n);
                    linspace(points(3,3), points(3,1), n)];

        % put all logether
        points = [points12,points23(:,2:end),points31(:,2:end)];
    end

end