function omega = wedge3(omegaHat)
%WEDGE3
%   The inverse operation of the hat3 function
    omega = [omegaHat(3,2); omegaHat(1,3); omegaHat(2,1)];
end

