function xi = wedge6(xiHat)
%WEDGE6
%   The inverse operation of the hat6 function
    
% extract omegaHat and v
v = xiHat(1:3,4);
omegaHat = xiHat(1:3, 1:3);

% get omega
omega = wedge3(omegaHat);

% build vector
xi = [v; omega];

end

